<?php
require"functions.php";
forgot_password("stelkooli@gmail.com");


?>