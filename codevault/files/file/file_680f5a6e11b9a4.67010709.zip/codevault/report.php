<?php
require "config.php";
require "templates.php";
require "functions.php";
is_login();
report_isset();

	




?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
	<script src="http://code.jquery.com/jquery-latest.js"></script>
    <title>CodeVault</title>
	<?php nav();?>
</head>
<body >
<h1>Problémába ütköztél? Értesíts bennünket</h1>
<form action='report.php' method='post'>
<input type='text' name='problem' placeholder='Üzenet...'>
<input type='submit' name='btn' >
</form>
	
 
</body>

</html>


