<?php
require "config.php";
require "templates.php";
require "functions.php";
is_login();


?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
	<link rel='stylesheet' href='styles.css'>
	<script src="http://code.jquery.com/jquery-latest.js"></script>
    <title>CodeVault</title>
	
</head>
<body >
	
	<section class="container mt-5">
    <div class="text-center">
        <h1 class="mb-4">Üdvözlünk a CodeVault oldalán!</h1>
        <p class="lead">
            A CodeVault egy egyedi platform, ahol egyedi kódkéréseket adhatsz le, 
            amelyeket adminisztrátoraink átnéznek, értékelnek, és jóváhagyás után megvásárolhatóvá tesznek.
        </p>
    </div>

    <div class="row mt-5">
        <div class="col-md-4">
            <h3>Szakmai ellenőrzés</h3>
            <p>Minden beküldött kérést szakértőink átnéznek és minősítenek, hogy garantált legyen a minőség.</p>
        </div>
        <div class="col-md-4">
            <h3>Biztonságos vásárlás</h3>
            <p>Csak ellenőrzött, jóváhagyott kódokat kínálunk megvételre, hogy nyugodt szívvel vásárolhass.</p>
        </div>
        <div class="col-md-4">
            <h3>Közösségi támogatás</h3>
            <p>Csatlakozz egy fejlődő közösséghez, ahol a tudásmegosztás és a szakmai segítség alapvető érték.</p>
        </div>
    </div>

    <div class="text-center mt-5">
        <a href="login.php" class="btn btn-primary btn-lg">Kérj saját kódot most!</a>
    </div>
</section>
</body>

</html>


