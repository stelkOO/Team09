<?php
require "config.php";
require "templates.php";
require "functions.php";

$chat = get_data("select * from chats where id=$_GET[id]");

if($chat['from_user'] ==get_user()['id']){
	$to = $chat['to_user'];
}else{
	$to = $chat['from_user'];
	
}

?>
<!DOCTYPE html>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
	<script src="http://code.jquery.com/jquery-latest.js"></script>
    <title>CodeVault</title>
	<?php nav();?>
</head>
<body>
<div class='chat-area'>

</body>
<?php

get_messages(get_user()['id'],$to,$_GET['id']);
message_send(get_user()['id'],$to,$_GET['id']);




?>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        window.scrollTo(0, document.body.scrollHeight);
    });
</script>