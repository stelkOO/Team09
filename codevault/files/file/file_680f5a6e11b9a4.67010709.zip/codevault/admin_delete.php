<?php
require "config.php";
require "templates.php";
require "functions.php";
is_login();
is_admin();
if(isset($_POST['cancel'])){
	alert_link("Visszairányítás a főoldalra", "admin_index.php");
}
if(isset($_POST['delete'])){
	$data_base = $_GET['data_base'];
	
	$conn->query("delete from $data_base where id=$_GET[id]");
	alert_link("Sikeres törlés","admin_index.php");
}




?>
<!DOCTYPE html>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
	<script src="http://code.jquery.com/jquery-latest.js"></script>
    <title>CodeVault</title>
	<?php nav();?>
</head>
<div class='box'>
<h2>Biztosan törölni szeretnéd?</h2>
<form method="post" action="admin_delete.php?data_base=<?= $_GET['data_base']; ?>&id=<?= $_GET['id']; ?>">
<input type='submit' name='cancel' value='Mégse' style='background-color:red; border-radius:5px; font-size:20px;'>
<input type='submit' name='delete' value='Törlés' style='background-color:green; border-radius:5px; font-size:20px;'>
</form>
<div>
<body>
</body>
</html>