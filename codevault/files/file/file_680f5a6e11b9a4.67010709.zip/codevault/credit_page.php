<?php
require "config.php";
require "templates.php";
require "functions.php";
is_login();

alert_link("Banki tranzakciók karban tartás alatt, kérlek próbáld meg később","index.php");



?>