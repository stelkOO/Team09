<?php
require "config.php";
require "templates.php";
require "functions.php";
is_login();
$user = get_user();


	




?>
<link rel="stylesheet" href="styles.css">
	<?php nav();?>

	<?php load_requests(" where userid=$user[id]");

?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="styles.css">
	<script src="http://code.jquery.com/jquery-latest.js"></script>
</head>

</html>
