 
 <?php
 require "config.php";
	
function forgot_password($to) {
    global $conn;
	
    
    $reset_code = code();
	$user = get_data("select * from users where email='$to'");
	$username = get_data("select * from users where email='$to'")['username'];

     $conn->query("insert into profile_codes  values (id,$user[id],'$reset_code','not_used')");

    $subject = "Elfelejtett jelszó helyreállítása";
    $message = "
    <html>
    <head>
    <title>Elfelejtett jelszó helyreállítása</title>
    </head>
    <body>
    <p>Kedves $username!</p>
    <p>Kérjük, kattintson az alábbi linkre a jelszava visszaállításához:</p>
    <p><a href='localhost/codevault/forgot_pass.php?code=$reset_code'>Jelszó visszaállítása</a></p>
    <p>Ha nem kérelmezte jelszava visszaállításást, akkor nyugodtan figyelmen kívül hagyhatja ezt az üzenetet.</p>
    <p>Üdvözlettel,<br>CodeVault</p>
    </body>
    </html>
    ";

    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8" . "\r\n";
    $headers .= "From: your-email@example.com" . "\r\n";

    if(mail($to, $subject, $message, $headers)) {
        echo "Az e-mail sikeresen elküldve.";
    } else {
        echo "Hiba történt az e-mail küldése során.";
    }
}
function get_messages($from,$to,$chat_id){
	global $conn;
	$sql = $conn->query("select * from messages where chat_id=$chat_id order by id asc");
	//from is the user, to is the user to the message
	echo "<div class='message-container'>";
	while($message = $sql->fetch_assoc()){
		if($message['from_id'] == $from){
			echo"<br>
			<div class='my-msg'>";
				echo $message['message'];
				
			echo"
			</div>
			";
		}else{
			echo"<br>
			<div class='to-msg'>";
				echo $message['message'];
				
			echo"
			</div>
			";
			
		}
		
		
	}
	echo "</div>";
	
	
}
function message_send($from, $to, $chat_id){
	global $conn;
	if(isset($_POST['send_btn'])){
		
		$conn->query("insert into messages values(id,$from,$to,$chat_id,'$_POST[message_field]')");
		header("location: chat.php?id=".$chat_id);
	}
	
	
echo "
    <form action='chat.php?id=" . $chat_id . "' method='POST' name='send-message'>
        <input type='text' name='message_field' placeholder='Üzenet....'>
        <input type='submit' value='Küldés' name='send_btn'>
    </form>
";

	
}
function regist_confirm($to){
	    global $conn;
	
    
    $reset_code = code();
	$user = get_data("select * from profile_requests where email='$to'");
	$username = get_data("select * from profile_requests where email='$to'")['username'];

     $conn->query("insert into profile_codes  values (id,$user[id],'$reset_code','not_used')");

    $subject = "Profil aktiválása";
    $message = "
    <html>
    <head>
    <title>Profil aktiválása</title>
    </head>
    <body>
    <p>Kedves $username!</p>
    <p>Kérjük, kattintson az alábbi linkre az aktiváláshoz:</p>
    <p><a href='localhost/codevault/engine_sites/activate_profile.php?code=$reset_code'>Profil aktiválása</a></p>
	<p>Üdvözlettel,<br>CodeVault</p>
    </body>
    </html>
    ";

    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8" . "\r\n";
    $headers .= "From: your-email@example.com" . "\r\n";

    if(mail($to, $subject, $message, $headers)) {
        echo "<scirpt>alert('Az e-mail sikeresen elküldve.')<script>";
    } else {
        echo "Hiba történt az e-mail küldése során.";
    }
}



function is_admin(){
	
	if(get_data("select * from users where id=$_COOKIE[userid]")['type'] !=1){
		alert_link("Nincs jogosultságod!","index.php");
	
	}
}
function is_admin_value(){
	if(get_data("select * from users where id=$_COOKIE[userid]")['type'] !=1){
		return false;
	
	}else{
		return true;
	}
}
function report_isset(){
	global $conn;
	if(isset($_POST['btn'])){
		$email= get_user()['email'];
		$conn->query("insert into reports values(id, '$email', '$_POST[problem]')");
		
		alert_link("Sikeres hibajelentés","index.php");
		
	}
	
}
function filter_value() {
    $filter = '';
    $conditions = [];
    $order = " ORDER BY id DESC";

    if (isset($_POST['btn'])) {
    
        if (!empty($_POST['filter']) && $_POST['filter'] !== 'empty') {
            $language = $_POST['filter'];
            $conditions[] = "language = '" . addslashes($language) . "'";
        }

      
        if (!empty($_POST['search'])) {
            $search = addslashes($_POST['search']);
           $conditions[] = "(description LIKE '%$search%' OR name LIKE '%$search%')";

        }

     
        if (isset($_POST['price_filter']) && is_numeric($_POST['price_filter'])) {
            $price = $_POST['price_filter'];
            $conditions[] = "token >= " . (int)$price; 
        }

     
        if (isset($_POST['sort_by'])) {
            if ($_POST['sort_by'] == 'date_asc') {
                $order = " ORDER BY id ASC";  
            } elseif ($_POST['sort_by'] == 'date_desc') {
                $order = " ORDER BY id DESC"; 
            } elseif ($_POST['sort_by'] == 'price_asc') {
                $order = " ORDER BY token ASC";
            } elseif ($_POST['sort_by'] == 'price_desc') {
                $order = " ORDER BY token DESC"; 
            }
        }

        
        if (!empty($conditions)) {
            $filter = " WHERE " . implode(" AND ", $conditions);
        }
    }

    return $filter . $order;
}



function load_requests($keresett) {
    global $conn;
    
    $lekerdezes = "select * from request $keresett";
    
    $lekerdezes = $conn->query($lekerdezes);
    if(mysqli_num_rows($lekerdezes) == 0){
        echo "<div class='box'>
            Nincs találat!
        </div>";
    }

    echo "<div class='requests-container'>";
    while ($request = $lekerdezes->fetch_assoc()) {
        $requestname = htmlspecialchars($request['name']);
        $description = htmlspecialchars(substr($request['description'], 0, 20)) . (strlen($request['description']) > 20 ? '...' : '');

        echo "<div class='doboz'>";
        echo "<a href='file.php?id={$request['id']}'><div class='code'>
                <h2>{$requestname}</h2>
              </div></a>
              <div class='leiras'><p>{$description}</p></div>
              <a href='file.php?id={$request['id']}'>" . $request['token'] . " token</a>";
        echo "</div>";
    }
    echo "</div>";
}


function load_requests_admin() {
	echo"<h2>Admin page!</h2>";
    global $conn;
	
    
   
    
      $lekerdezes = "select * from files where review=''";
    

    $lekerdezes = $conn->query($lekerdezes);
	if(mysqli_num_rows($lekerdezes) ==0){
		echo"<div class='admin_file'>Nincs több értékelendő fájl!</div>";
		exit();
	}
	echo "Hátramaradt fájlok: ".mysqli_num_rows($lekerdezes);
	$file = $lekerdezes->fetch_assoc();
	if(isset($_POST['btn'])){
		$conn->query("UPDATE files SET review='$_POST[review]', stars=$_POST[stars] WHERE id=$file[id]");
		alert_link("Sikeres feltöltés!","admin_index.php");
		
	}
	
	
	
	
	echo "<div class='admin_file'>";
		echo $file['filename'];
	echo "</div>";
		echo "<div class='admin_request'>";
		echo get_data("select * from request where id = $file[requestid]")['name'];
		echo get_data("select * from request where id = $file[requestid]")['description'];
	echo "</div>";
	echo"<a href='file_download.php?id=$file[id]'>Fájl letöltése</a>";
	// file_download($file['id']);
	echo"<form action='admin_index.php' method='post'>
	<input type='text' placeholder='fájl értékelése' name='review' required>
	<select name='stars' required>
	<option value='1'>1</option>
	<option value='2'>2</option>
	<option value='3'>3</option>
	<option value='4'>4</option>
	<option value='5'>5</option>
	</select>
	<input type='submit' name='btn' value='Értékelés'>
	</form>
	
	
	";
	 
	
	

   
}
function load_notifications(){
	global $conn;
	$userid = get_user()['id'];
	$sql = $conn->query("select * from notifications where to_id=$userid");
	while($notification = $sql->fetch_assoc()){
		if($notification['status'] == 0){
			echo "<div class='notification_unseen'>";
			echo $notification['content'];
			echo "</div>";
		}else{
			
			echo "<div class='notification_seen'>";
			echo $notification['content'];
			echo "<a href='$notification[link]'>Link</a>";
			
			echo "</div>";
		}
		
	}
	
}
function see_notifications(){
	global $conn;
	$userid = get_user()['id'];
	$sql = $conn->query("select * from notifications where to_id=$userid and status=0");
	while($notification = $sql->fetch_assoc()){
		$conn->query("update notifications set status =1 where id=$notification[id]");
		
	}
	
}

function unseen_notifications(){
	global $conn;
	$userid = get_user()['id'];
	$sql = $conn->query("select * from notifications where to_id=$userid and status=0");
	$count = mysqli_num_rows($sql);
	return $count;
}

function upload_notification($from, $to, $content, $link){
    global $conn;

    $safe_content = mysqli_real_escape_string($conn, $content);
    $safe_link = mysqli_real_escape_string($conn, $link);

    $conn->query("INSERT INTO notifications VALUES (id,$from, $to, '$safe_content', 0, '$safe_link')");
}


function load_reviews($keresett){
	global $conn;
	$lekerdezes  = $conn->query($keresett);
	 while ($review = $lekerdezes->fetch_assoc()) {
        $review_writer = get_data("select * from users where id=$review[from_id]")['username'];
        $description = $review['description'];

        echo "<div class='doboz'>";
        echo "<a href='user_profile.php?id={$review['from_id']}'><div class='code'>
                <h2>{$review_writer}</h2>
              </div></a>
              <div class='leiras'><p>{$description}</p></div>";
        echo "</div>";
    }
    echo "</div>";
	
}
function load_files($keresett) {
    global $conn;

    
    $lekerdezes = $keresett;
    if (empty($keresett)) {
      $lekerdezes = "select * from files order by upload_date desc";
    }

    $lekerdezes_files = $conn->query($lekerdezes);
	
    echo "<div class='requests-container'>";
    while ($file = $lekerdezes_files->fetch_assoc()) {
    
        $description =$file['review'];
        $rating =$file['stars'];
		
        echo "<div class='doboz'>";
        echo "<a href='file.php?id={$file['id']}'><div class='code'>
                <h2>{$file['upload_date']}</h2>
              </div></a>
              <div class='leiras'><p>{$description}</p></div>
              <div class='leiras'><p>{$rating} /5 <i class='fa-regular fa-star'></i></p></div>";
             
			  $bought = false;
			  $f_purchases = $conn->query("select * from buy_history where file_id=$file[id]");
			  while($file_purchased = $f_purchases->fetch_assoc()){
				  if($file_purchased['buyer_id'] == get_user()['id']){
					  $bought = true;
				  }
				  
			  }
			  if($bought == false){
				echo " <div class='buy_btn'><a href='confirm.php?file_id=$file[id]'>Megvásárlom</a></div>

			  ";
			  }else{
				 echo "<form action='my_purchases.php?download_id={$file['id']}' method='post'>
				<input type='submit' name='download_btn' value='Letöltés'>
				</form>";

			  }
        echo "</div>";
    }
    echo "</div>";

}

function load_purchases($sql) {
    global $conn;

    if (empty($sql)) {
        $sql = "SELECT * FROM buy_history ORDER BY date DESC";
    }

    $lekerdezes = $conn->query($sql);


    echo '<div class="cart-container">';

    if ($lekerdezes->num_rows == 0) {
        echo '<p class="no-items">Nincsenek vásárolt fájlok.</p>';
    }

    while ($purchase = $lekerdezes->fetch_assoc()) {
        $file = get_data("SELECT * FROM files WHERE id=" . $purchase['file_id']);

        if (!$file) {
            echo '<p class="error">Hiba: Nem található fájl az adatbázisban.</p>';
            continue;
        }

        // Ha van fájl leírás, azt használjuk, ha nincs, akkor a fájl nevét írjuk ki
        $fileDescription = !empty($file['description']) ? $file['description'] : "Fájl neve: " . htmlspecialchars($file['filename']);

        echo '
        <div class="cart-item">
            <h2>' . date("Y-m-d", strtotime($purchase['date'])) . '</h2>
            <p>' . htmlspecialchars($fileDescription) . '</p>
            <a href="file.php?id=' . $file['id'] . '" class="download-btn">Letöltés</a>
        </div>';
    }

    echo '</div>';
}



/**/
//alert from php
function message($message){
	echo "<script>alert('$message'); </script>";
	
	
}

function is_login(){
    if (!isset($_COOKIE['userid'])) {
        echo "<script>
            alert('Jelentkezz be a folytatáshoz!');
            window.location.href = 'login.php?site=login';
        </script>";
        exit;
    }
}

function alert_link($message,$location){
	echo "<script>
            alert('$message');
            window.location.href = '$location';
        </script>";
        exit;
	
}
function code(){
	global $conn;
	code:
	$characters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z','0', '1', '2','3', '4', '5', '6', '7', '8', '9' ];
	
	$code ='';
	global $conn;
	for($i=0; $i< 8; $i++){
		$code.=$characters[rand(0,count($characters)-1)];
	}
	
	if(mysqli_num_rows($conn->query("select * from profile_codes where code='$code'")) >0){
		goto code;
	}else{
		return $code;
	}
	
}

function upload_file($request_id){
	global $conn;
	
	   $cel_mappa = "files/file/";
	 // Feltöltött fájl neve
	 $fajl_nev = $_FILES['file-to-upload']['name'];
    
    // Fájl kiterjesztése
    $fajl_tipus = pathinfo($fajl_nev, PATHINFO_EXTENSION);
	$request = get_data("select * from request where id = $request_id");
	
    // meret
    $fajl_merete = $_FILES['file-to-upload']['size'];

   
    $elfogadott_tipusok = ['zip'];

   
    $max_fajl_merete = 20 * 1024 * 1024;

    // Új, egyedi fájl név generálása
    $fajl_nev = uniqid('file_', true) . '.' . $fajl_tipus;
    $cel_fajl = $cel_mappa . $fajl_nev;

    // fájl tipus
    if (!in_array(strtolower($fajl_tipus), $elfogadott_tipusok)) {
        echo "<script>alert('Csak .zip fájlokat tölthetsz fel!');</script>";
    }
    //meret
    elseif ($fajl_merete > $max_fajl_merete) {
        echo "<script>alert( Maximum 10 MB engedélyezett');</script>";
    } 
   
    else {
        // Ellenőrizzük, hogy a fájl van e már
        if (file_exists($cel_fajl)) {
            echo "<script>alert('Próbáld meg kérlek újra!');</script>";
        } else {
            
            $date = date('Y-m-d H:i:s');
            
            // fájl adatai feltöltése az adatbázisba
            $conn->query("INSERT INTO files VALUES (id,$_COOKIE[userid], '$fajl_nev', '$date', $request_id,'',$request[token])");

            // fájl áthelyezése a megfelelő mappába
            move_uploaded_file($_FILES['file-to-upload']['tmp_name'], $cel_fajl);
            echo "<script>alert('Sikeres feltöltés!');</script>";
			echo "<script>
            if (confirm('Vissza a főoldalra!')) {
                window.location.href = 'index.php';
            }
        </script>";
        exit;
			
        }
    }
	
}
function submit_review($from_id){
	global $conn;
	$my_user=get_user();
	// $from_user = get_data("select * from users where id=$from_id");
	$has_payment =  false;
	$payments = $conn->query("select * from buy_history where (provider_id=$my_user[id] and buyer_id=$from_id)
	or (provider_id=$from_id and buyer_id=$my_user[id])
	");
	if(mysqli_num_rows($payments) > 0){
		$has_payment = true;
		
	}
	if($has_payment){
		$conn->query("insert into ratings values(id, $_POST[point],'$_POST[description]',$from_id,$my_user[id])");
		alert_link("Sikeres közzététel","index.php");
		
	}else{
		alert_link("Nem található vásárlás","index.php");
		
	}
		
	
	
	
	
}
function user_rating($userid){
	global $conn;
	$points = 0;
	$counter = 0;
	$sql = $conn->query("select * from ratings where to_id=$userid");
	while($rating = $sql->fetch_assoc()){
		$counter+=1;
		$points+=$rating['points'];
		
	}
	return $counter > 0 ? $points/$counter : 0;
	
}
function get_data($lekerdezes){
	global $conn;
	$f_data = $conn->query($lekerdezes);
	$data = $f_data->fetch_assoc();
	return $data;
	
	
}

function new_chat($to,$from){
	global $conn;
	
	$is_blocked = $conn->query("select * from blocked where (from_user=$to and to_user=$from) or (from_user=$from and to_user=$to)");
	if(mysqli_num_rows($is_blocked) > 0){
		alert_link("Ez a művelet nem teljesíthető","index.php");
		exit();
		
	}
	
	$has_conv = $conn->query("select * from chats where (from_user=$to and to_user=$from) or (from_user=$from and to_user=$to)");
	if(mysqli_num_rows($has_conv) > 0){
		alert_link("Már létezik ez a beszélgetés","index.php");
		exit();
		
	}
	$conn->query("insert into chats values(id, $from,$to)");
}
function get_chats($user_id){
	global $conn;
	$chats = $conn->query("select * from chats where from_user=$user_id or to_user=$user_id");
	while($chat = $chats->fetch_assoc()){
	
		if($chat['from_user'] == get_user()['id']){
			$other_user = $chat['to_user'];
		}else{
			$other_user = $chat['from_user'];
		}
		
		echo "<div class='chat_box'>
        <a href='chat.php?id=" . $chat['id'] . "'>" . get_data("select * from users where id=$other_user")['username'] . "</a>
      </div>";


	}
	
}

function get_user(){
	global $conn;
	$f_user = $conn->query("select * from users where id = $_COOKIE[userid]");
	$user = $f_user->fetch_assoc();
	return $user;
	
}
function file_payment($file_id,$provider_id,$buyer_id,$credits){
	global $conn;
	$date = date('Y-m-d H:i:s'); 
	$link = "http://localhost/codevault/file.php?id=" . $file_id;
	upload_notification($buyer_id,$provider_id,"Feltöltött fájlod sikeresen megvásárolták!",$link);
	$conn->query("insert into buy_history values(id,$file_id,$provider_id,$buyer_id,$credits,'$date')");
	
	
	
}

function file_download($file_id){
	global $conn;
	$file = get_data("select * from files where id=$file_id");
	$file_path = "files/file/{$file['filename']}";



if (file_exists($file_path)) {

    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file_path));

   
    readfile($file_path);
    exit;
} else {
    echo "Hiba: A fájl nem található!";
}
	
	
	
}
 ?>


 
 
 
 