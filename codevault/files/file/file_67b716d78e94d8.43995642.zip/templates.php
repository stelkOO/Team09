<?php
function nav(){
	?>
	
<nav>
    <a href="index.php"></a>
    <a href="#"></a>

    <?php if (!isset($_COOKIE['userid'])): ?>
        <a href="login.php?site=login"></a>
    <?php else: ?>
        <a href="upload.php"> </a>
        <a href="logout.php"></a>
    <?php endif; ?>

    
</nav>



<?php }
//nem hasznalt funkcio egyelore
function kereso() {
    ?>

   
    <form id="searchForm" method="POST" onsubmit="return false;">
        <input type="text" id="searchInput" name="search" placeholder="Keresés a leírásban..." onkeyup="searchRequests()">
    </form>

 
    <div id="results">
       
    </div>

    <script>
        function searchRequests() {
            var keresett = document.getElementById("searchInput").value;

         
            $.ajax({
                url: "engine_sites/search.php",
                method: "POST",  
                data: { search: keresett },  
                success: function(response) {
                   
                    document.getElementById("results").innerHTML = response;
                }
            });
        }
    </script>


  <?php } ?>

